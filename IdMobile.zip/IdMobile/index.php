<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$idNumber = check_login($con);

?>

<html>
    <head>
        <title>Welcome></title>
</head>
<body>
    Welcome
</body>
</html>